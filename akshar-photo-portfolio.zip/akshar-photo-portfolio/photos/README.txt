Place public, optimized JPG or WebP copies here. Add their paths and descriptive alt text to ../gallery.js. Do not put private originals here; deployed files are public.
